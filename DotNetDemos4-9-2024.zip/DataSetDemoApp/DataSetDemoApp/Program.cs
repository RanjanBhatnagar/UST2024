﻿using System.Data;
using System.Data.SqlClient;
namespace DataSetDemoApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            //connection object for SQL Server Database.
            //connection string is defined in App.config file
            using (SqlConnection connection = new SqlConnection(Helper.ConnectionString))
            {
                //Create the SqlDataAdapter instance by specifying the command text and connection object
                SqlDataAdapter dataAdapter = new SqlDataAdapter("select Id,EmpName,EmpSalary from Emp", connection);

                //Creating DataSet Object
                DataSet dataSet = new DataSet();

                //Filling the DataSet using the Fill Method of SqlDataAdapter object
                //Here, we have not specified the data table name and the data table will be created at index position 0
                dataAdapter.Fill(dataSet);

                //Iterating through the DataSet 
                //First fetch the Datatable from the dataset and then fetch the rows using the Rows property of Datatable
                Console.WriteLine("Emp Id\tEmp Name\tEmp Salary");
                Console.WriteLine("==================================");
                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    //Accessing the Data using the string column name as key
                    Console.WriteLine(row["Id"] + "\t  " + row["EmpName"] + "\t\t" + row["EmpSalary"]);
                }
            }
        }
    }
}
