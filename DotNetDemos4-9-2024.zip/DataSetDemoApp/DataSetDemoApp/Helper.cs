﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace DataSetDemoApp
{
    public static class Helper
    {
        public static string ConnectionString
        {
            get 
            {
                return ConfigurationManager.ConnectionStrings["csUSTDemoDB"].ConnectionString;
            }
        }
    }
}
