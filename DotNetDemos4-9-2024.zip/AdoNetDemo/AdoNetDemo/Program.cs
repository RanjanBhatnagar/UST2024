﻿using System.Data;
using System.Data;
using Microsoft.Data.SqlClient;

namespace AdoNetDemo
{
    public class Program
    {
        static SqlConnection con = new SqlConnection(Helper.ConnectionString);
        static void Main(string[] args)
        {
            //Insert new record and get newly generated EmpId
            //AddNew();

            //Update particular emp's salary
            //UpdateEmpRec();

            //delete record of emp by id
            //DeleteEmpRec();

            //Show all the records in tabular data
            //DisplayAll();

            //Show details of emp by empid
            //Console.Write("Enter Emp Id:");
            //int empid = int.Parse(Console.ReadLine());
            //DispalayEmp(empid);

            //Using id as Parameter in Sql Parameters
            //DisplayEmpParam();

            //Get a salary of emp by ID using Stored Procedure
            //ShowSalarySP();


            //InsertEmpSP

            //GetAllRecordsSP

        }

        public static void ShowSalarySP()
        {
            SqlConnection con = new SqlConnection(Helper.ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "GetSalary";
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parId, parSalary;
            parId = new SqlParameter("@Id", SqlDbType.Int);
            parSalary = new SqlParameter("@Sal", SqlDbType.Money);
            parSalary.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parId);
            cmd.Parameters.Add(parSalary);
            Console.Write("Enter Emp Id:");
            parId.Value = int.Parse(Console.ReadLine());

            con.Open(); cmd.ExecuteNonQuery(); con.Close();

            string result = string.Empty;
            if (parSalary.Value == DBNull.Value)
                result= "No Data Found";
            else
                result= parSalary.Value.ToString();

            Console.WriteLine("Salary:" + result);
        }

        public static void DisplayEmpParam()
        {
            using (SqlConnection con = new SqlConnection(Helper.ConnectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("Select * from Emp where Id=@id", con))
                {
                    cmd.Parameters.Add("@id", SqlDbType.Int);
                    Console.Write("Enter id:");
                    cmd.Parameters["@id"].Value = int.Parse(Console.ReadLine());
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dr.Read();
                        Console.WriteLine("Name: " + dr[1].ToString()
                            + "\nSalary: " + dr[2].ToString());
                    }
                }
            }
        }
        public static void DispalayEmp(int empid)
        {
            SqlConnection con = new SqlConnection(Helper.ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from Emp where id=" + empid + ";", con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            string str = "Emp Id \t     EmpName \t     EmpSalary\n";
            while (dr.Read())
            {
                str += dr[0].ToString() + "\t      ";
                str += dr["EmpName"] + "\t     ";
                int indSalary = dr.GetOrdinal("EmpSalary");
                if (dr.IsDBNull(indSalary))
                    str += "----\n";
                else
                    str += dr.GetDecimal(indSalary) + "\n";
            }
            Console.WriteLine(str);
            dr.Close();
            con.Close();
        }
        public static void DisplayAll()
        {
            SqlConnection con = new SqlConnection(Helper.ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from Emp", con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            string str = "Emp Id \t     EmpName \t     EmpSalary\n";
            while (dr.Read())
            {
                str += dr[0].ToString() + "\t      ";
                str += dr["EmpName"] + "\t     ";
                int indSalary = dr.GetOrdinal("EmpSalary");
                if (dr.IsDBNull(indSalary))
                    str += "----\n";
                else
                    str += dr.GetDecimal(indSalary) + "\n";
            }
            Console.WriteLine(str);
            dr.Close();
            con.Close();
        }
        public static void DeleteEmpRec()
        {

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            Console.Write("Enter EmpID to delete a record:");
            int empid = int.Parse(Console.ReadLine());
            cmd.CommandText = "Delete from Emp where Id=" + empid + ";";
            cmd.CommandType = CommandType.Text;
            con.Open();
            cmd.ExecuteNonQuery();
            Console.WriteLine("Row Deleted...");
            con.Close();

        }
        public static void UpdateEmpRec()
        {
            Console.Write("Eneter Emp Id:");
            int empid = int.Parse(Console.ReadLine());
            Console.Write("Enter New Salary:");
            decimal salary = decimal.Parse(Console.ReadLine());
            SqlConnection con = new SqlConnection(Helper.ConnectionString);
            /*
             Update Emp set EmpSalary=<salary> where id=<empid>
            update Emp set EmpSalary = 50000 where id=103;
             * */
            string sqlquery = "update Emp set EmpSalary =" + salary.ToString() + "where id = " + empid.ToString() + ";";
            SqlCommand cmd = new SqlCommand(sqlquery, con);
            con.Open();
            int numrow = cmd.ExecuteNonQuery();
            if (numrow == 0)
                Console.WriteLine("No record updated");
            con.Close();
        }
        public static void AddNew()
        {
            /* We want to store a new record in Emptable of USTDemoDB database.
             * We are writing everything in Main for learning purpose only
             * Steps to execute any SQL Statement under connected approach
                    1. Create a Connection Object
                    2. Create a Command Object
                    3. Bind the Command to Connection
                    4. Initialize Command with SQL Statement
                    5. Open the Connection
                    6. Execute the Command
                    7. Close the Connection
             * */
            // Create a Connection Object (SQL Server -- SQLClient - SQLConnection class)
            SqlConnection con = new SqlConnection();
            con.ConnectionString = Helper.ConnectionString;

            //SqlConnection con = new SqlConnection(Helper.ConnectionString);

            //Create a Command Object  (for CRUD -- Here insert is to be used)
            SqlCommand cmd = new SqlCommand();

            //Bind the Command to Connection
            cmd.Connection = con;

            //Obtain Data from EndUser.
            Console.Write("Enter Name:");
            string ename = Console.ReadLine();
            Console.Write("Enter Salary:");
            decimal salary = decimal.Parse(Console.ReadLine());
            //Initialize Command with SQL Statement
            cmd.CommandText = "Insert into Emp(EmpName, EmpSalary) values('" + ename + "'," + salary + ");";
            cmd.CommandType = CommandType.Text;

            //Open the Connection
            con.Open();

            //execute to insert record
            cmd.ExecuteNonQuery();

            //Displaying newly genereted EmpId.
            cmd.CommandText = "Select @@Identity";
            int empid = int.Parse(cmd.ExecuteScalar().ToString());
            Console.WriteLine($"Record of {ename} is created and his Id is {empid}");


            //close the connection
            con.Close();

        }

    }
}
